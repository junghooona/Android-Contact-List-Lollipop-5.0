package com.example.mycontactlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class ContactSettingsActivity extends AppCompatActivity {
    private void initListButton(){
        ImageButton ibList = findViewById (R.id.imageButtonList);
        ibList.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(ContactSettingsActivity.this, ContactListActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initMapButton(){
        ImageButton ibList = findViewById(R.id.imageButtonMap);
        ibList.setOnClickListener(new View.OnClickListener()  {
            public void onClick(View view){
                Intent intent = new Intent(ContactSettingsActivity.this, ContactMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initSettingsButton(){
        ImageButton ibList = findViewById(R.id.imageButtonSettings);
        ibList.setOnClickListener(new View.OnClickListener()  {
            public void onClick(View view){
                Intent intent = new Intent(ContactSettingsActivity.this, ContactSettingsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

    private void initSettings() {
        String sortBy = getSharedPreferences("MyContactListPreferences",
                Context.MODE_PRIVATE).getString("sortfield", "contactname");
        String sortOrder = getSharedPreferences("MyContactListPreferences",
                Context.MODE_PRIVATE).getString("sortorder", "ASC");
        String theme = getSharedPreferences("MyContactListPreferences",
                Context.MODE_PRIVATE).getString("theme", "blue");
        RadioButton rbBlue = findViewById(R.id.radioBlue);
        RadioButton rbRed = findViewById(R.id.radioRed);
        RadioButton rbGreen = findViewById(R.id.radioGreen);
        if(theme.equalsIgnoreCase("blue")) {
            rbBlue.setChecked(true);
        }
        else if(theme.equalsIgnoreCase("red")){
            rbRed.setChecked(true);
        }
        else {
            rbGreen.setChecked(true);
        }
        RadioButton rbName = findViewById(R.id.radioName);
        RadioButton rbCity = findViewById(R.id.radioCity);
        RadioButton rbBirthday = findViewById(R.id.radioBirthday);
        if (sortBy.equalsIgnoreCase("contactname")) {
            rbName.setChecked(true);
        }
        else if(sortBy.equalsIgnoreCase("city")) {
            rbCity.setChecked(true);
        }
        else {
            rbBirthday.setChecked(true);
        }
        RadioButton rbAscending = findViewById(R.id.radioAscending);
        RadioButton rbDescending = findViewById(R.id.radioDescending);
        if(sortOrder.equalsIgnoreCase("ASC")){
            rbAscending.setChecked(true);
        }
        else {
            rbDescending.setChecked(true);
        }

    }
    private static String themeColor;
    public static String getColor(){
        return themeColor;
    }
    private void initThemeClick(){
        RadioGroup rgTheme = findViewById(R.id.radioGroupTheme);
        ConstraintLayout constraintSettings = findViewById(R.id.constraintSettings);
        rgTheme.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
            RadioButton rbBlue = findViewById(R.id.radioBlue);
            RadioButton rbRed = findViewById(R.id.radioRed);
            if(rbBlue.isChecked()) {
                getSharedPreferences("MyContactListPreferences",
                        Context.MODE_PRIVATE).edit().putString("theme", "blue").apply();
                constraintSettings.setBackgroundResource(R.color.light_teal);
                themeColor = "blue";
            }
            else if(rbRed.isChecked()){
                getSharedPreferences("MyContactListPreferences",
                        Context.MODE_PRIVATE).edit().putString("theme", "red").apply();
                constraintSettings.setBackgroundResource(R.color.light_red);
                themeColor = "red";
            }
            else{
                getSharedPreferences("MyContactListPreferences",
                        Context.MODE_PRIVATE).edit().putString("theme", "green").apply();
                constraintSettings.setBackgroundResource(R.color.light_green);
                themeColor = "green";
            }

            }
        });
    }
    private void initSortByClick() {
        RadioGroup rgSortBy = findViewById(R.id.radioGroupSortBy);
        rgSortBy.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rbName = findViewById(R.id.radioName);
                RadioButton rbCity = findViewById(R.id.radioCity);
                if(rbName.isChecked()){
                    getSharedPreferences("MyContactListPreferences",
                            Context.MODE_PRIVATE).edit()
                    .putString("sortfield", "contactname").apply();
                }
                else if(rbCity.isChecked()){
                    getSharedPreferences("MyContactListPreferences",
                            Context.MODE_PRIVATE).edit()
                            .putString("sortfield", "city").apply();
                }
                else{
                    getSharedPreferences("MyContactListPreferences",
                            Context.MODE_PRIVATE).edit()
                            .putString("sortfield", "birthday").apply();
                }
            }
        });
    }
    private void initSortOrderClick(){
        RadioGroup rgSortOrder = findViewById(R.id.radioGroupSortOrder);
        rgSortOrder.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup group, int i) {
                RadioButton rbAscending = findViewById(R.id.radioAscending);
                if(rbAscending.isChecked()){
                        getSharedPreferences("MyContactListPreferences",
                                Context.MODE_PRIVATE).edit()
                                .putString("sortorder", "ASC").apply();
                    }
                    else{
                        getSharedPreferences("MyContactListPreferences",
                                Context.MODE_PRIVATE).edit()
                                .putString("sortorder", "DESC").apply();
                    }
                }
            });
}
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_settings);
        initListButton();
        initMapButton();
        initThemeClick();
        initSettings();
        initSortByClick();
        initSortOrderClick();
    }
}