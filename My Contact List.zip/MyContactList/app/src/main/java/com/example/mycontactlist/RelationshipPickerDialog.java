package com.example.mycontactlist;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;
import java.util.Map;
import java.util.Set;

public class RelationshipPickerDialog extends DialogFragment {
    String selectedRelationship = "";

    public interface SaveRelationshipListener {
        void didFinishRelationshipPickerDialog(String selectedRelationship);
    }

    RelationshipPickerDialog() {
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.select_relationship, container);
        getDialog().setTitle("Select Relationship");
        RadioGroup radioGroupRelationship = view.findViewById(R.id.radioGroupRelationship);

        radioGroupRelationship.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton rbFriend = view.findViewById(R.id.radioFriend);
                RadioButton rbFamily = view.findViewById(R.id.radioFamily);
                RadioButton rbCoworker = view.findViewById(R.id.radioCoworker);
                if (rbFriend.isChecked()) {
                    selectedRelationship = "Friend";
                } else if (rbFamily.isChecked()) {
                    selectedRelationship = "Family";
                } else if (rbCoworker.isChecked()) {
                    selectedRelationship = "Coworker";
                } else {
                    selectedRelationship = "Acquaintance";
                }
            }
        });
        Button buttonOkRelationship = view.findViewById(R.id.buttonOkRelationship);
        buttonOkRelationship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveRelationship(selectedRelationship);
            }
        });
        Button buttonCancelRelationship = view.findViewById(R.id.buttonCancelRelationship);
        buttonCancelRelationship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getDialog().dismiss();
            }
        });
    return view;
    }
            private void saveRelationship(String relationship) {
        SaveRelationshipListener activity = (SaveRelationshipListener) getActivity();
        activity.didFinishRelationshipPickerDialog(relationship);
        getDialog().dismiss();
    }
}

